const products=[
 {id:1,name:"NovaBuds Pro",price:20,desc:"Generic wireless Bluetooth earbuds with charging case.",stock:8},
 {id:2,name:"NOVA Grip",price:12,desc:"Everyday grip accessory. Replace with your real product.",stock:12},
 {id:3,name:"NOVA Carry",price:18,desc:"Compact everyday accessory pouch.",stock:6}
];
let cart=JSON.parse(localStorage.getItem("nova_cart")||"[]");
const money=n=>new Intl.NumberFormat("en-CA",{style:"currency",currency:"CAD"}).format(n);
const productsEl=document.querySelector("#products");
function renderProducts(list=products){
 productsEl.innerHTML=list.map(p=>`<article class="card"><div class="photo">NOVA</div><div class="card-body"><h3>${p.name}</h3><p class="muted">${p.desc}</p><div class="row"><span class="price">${money(p.price)}</span><button class="buy" onclick="add(${p.id})" ${p.stock<1?"disabled":""}>${p.stock<1?"Sold out":"Add to cart"}</button></div></div></article>`).join("")||'<p class="muted">No products found.</p>';
}
function save(){localStorage.setItem("nova_cart",JSON.stringify(cart));renderCart();}
function add(id){const p=products.find(x=>x.id===id);if(!p)return;const item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({id,qty:1});save();openCart();}
function remove(id){cart=cart.filter(x=>x.id!==id);save();}
function renderCart(){
 const el=document.querySelector("#cartItems");
 document.querySelector("#cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0);
 let total=0;
 el.innerHTML=cart.length?cart.map(x=>{const p=products.find(y=>y.id===x.id);const sum=p.price*x.qty;total+=sum;return `<div class="cart-item"><div><strong>${p.name}</strong><div class="muted">${x.qty} × ${money(p.price)}</div></div><button onclick="remove(${p.id})">Remove</button></div>`}).join(""):'<p class="muted">Your cart is empty.</p>';
 document.querySelector("#subtotal").textContent=money(total)+" CAD";
}
function openCart(){document.querySelector("#drawer").classList.add("open");document.querySelector("#overlay").classList.add("show")}
function closeCart(){document.querySelector("#drawer").classList.remove("open");document.querySelector("#overlay").classList.remove("show")}
document.querySelector("#cartOpen").onclick=openCart;
document.querySelector("#cartClose").onclick=closeCart;
document.querySelector("#overlay").onclick=closeCart;
document.querySelector("#search").oninput=e=>{const q=e.target.value.toLowerCase();renderProducts(products.filter(p=>(p.name+" "+p.desc).toLowerCase().includes(q)))};
document.querySelector("#orderBtn").onclick=()=>{if(!cart.length)return alert("Your cart is empty.");alert("Order request demo: connect your email/payment system before launch.");};
renderProducts();renderCart();
