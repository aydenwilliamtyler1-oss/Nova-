# NOVA Store

A free static storefront starter built with HTML, CSS and JavaScript.

## Included
- Responsive storefront
- Product catalog
- Search
- Cart with localStorage
- Order-request placeholder
- Dark NOVA branding

## Important
This starter intentionally does NOT pretend to have secure admin authentication, real payment processing, or server-side inventory. Those require a backend/database and HTTPS.

For a real production store, add:
- a backend/database
- authenticated admin accounts
- WebAuthn/passkeys (Face ID on supported Apple devices)
- a payment processor
- server-side inventory and order handling

## Publish free
Upload `index.html`, `styles.css`, and `app.js` to a GitHub repository and enable GitHub Pages.
